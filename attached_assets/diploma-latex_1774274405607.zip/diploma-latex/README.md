# Дипломын ажлын LaTeX загвар

## Сэдэв
Ресторааны ширээ захиалга, цэс удирдлагын мобайл системийн загварчлал, хэрэгжилт

## Файлын бүтэц

```
diploma-latex/
├── main.tex                     # Үндсэн файл (энд эхлүүлнэ)
├── latexmkrc                    # XeLaTeX тохиргоо
├── references.bib               # Ном зүй (BibTeX)
├── images/                      # Зургийн хавтас
└── chapters/
    ├── 00_titlepage.tex         # Гарчиг хуудас
    ├── 01_approval.tex          # Зөвшөөрөл, Төлөвлөгөө
    ├── 02_plan.tex              # Ажлын явц
    ├── 03_review.tex            # Шүүмжийн хуудас
    ├── 04_copyright.tex         # Зохиогчийн эрх
    ├── 05_abstract.tex          # Хураангуй (Монгол + Англи)
    ├── 06_introduction.tex      # Оршил
    ├── 07_chapter1.tex          # Бүлэг 1: Судалгааны тойм, шаардлага
    ├── 08_chapter2.tex          # Бүлэг 2: Загварчлал
    ├── 09_chapter3.tex          # Бүлэг 3: Хэрэгжилт
    ├── 10_chapter4.tex          # Бүлэг 4: Туршилт, дүгнэлт
    ├── 11_conclusion.tex        # Дүгнэлт
    └── 12_appendix.tex          # Хавсралт
```

## Хэрхэн бүтэц гаргах вэ

### Арга 1: latexmk (санал болгоно)
```bash
cd diploma-latex
latexmk -pdf main.tex
```

### Арга 2: XeLaTeX гараар
```bash
cd diploma-latex
xelatex main.tex
bibtex main
xelatex main.tex
xelatex main.tex
```

### Арга 3: Overleaf
- Overleaf.com дээр шинэ төсөл үүсгэж бүх файлыг upload хийнэ
- Compiler-ийг **XeLaTeX** болгоно
- `main.tex` файлыг compile хийнэ

## Тохируулах хэсгүүд

### Гарчиг хуудас (`chapters/00_titlepage.tex`)
- Оюутны нэр
- Удирдагч, зөвлөгчийн нэр
- Мэргэжлийн индекс

### Зурагнуудыг нэмэх
- Зургийн файлуудыг `images/` хавтасд хийнэ
- `\fbox{...}` placeholder-уудыг `\includegraphics[width=...]{images/filename}` болгон сольно

### Зохиогчийн мэдээлэл
- Хавсралт С-д нэрээ, дипломын зэргийн мэдээллийг оруулна

## Шаардагдах LaTeX багцууд
- `polyglossia` (Монгол хэлний дэмжлэг)
- `fontspec` (XeLaTeX)
- `geometry`, `setspace`, `fancyhdr`
- `graphicx`, `float`, `caption`, `subcaption`
- `booktabs`, `tabularx`, `longtable`
- `listings`, `xcolor`
- `natbib`
- `hyperref`
